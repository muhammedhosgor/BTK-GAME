import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_base_app/product/components/button/image_button.dart';
import 'package:flutter_base_app/product/constant/color_constants.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lottie/lottie.dart';

enum Suit { hearts, diamonds, clubs, spades }

class PlayingCard {
  final Suit suit;
  final String rank; // 'A', '2'..'10', 'J', 'Q', 'K'
  bool disabled = false; // Karo 2 ile etkisizleştirilirse true

  PlayingCard(this.suit, this.rank);

  String get suitSymbol {
    switch (suit) {
      case Suit.hearts:
        return '♥';
      case Suit.diamonds:
        return '♦';
      case Suit.clubs:
        return '♣';
      case Suit.spades:
        return '♠';
    }
  }

  int get value {
    if (disabled) return 0;
    if (rank == 'A') return 1;
    if (rank == 'J') return 11;
    if (rank == 'Q') return 12;
    if (rank == 'K') return 13;
    return int.tryParse(rank) ?? 0;
  }

  bool get isKingOfHearts => suit == Suit.hearts && rank == 'K';
  bool get isClubs2 => suit == Suit.clubs && rank == '2';
  bool get isDiamonds2 => suit == Suit.diamonds && rank == '2';

  @override
  String toString() => '$rank${suitSymbol}';
}

class Deck {
  final List<PlayingCard> _cards = [];
  final Random _rnd = Random();

  Deck() {
    final ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    for (var s in Suit.values) {
      for (var r in ranks) {
        _cards.add(PlayingCard(s, r));
      }
    }
    shuffle();
  }

  void shuffle() => _cards.shuffle(_rnd);

  PlayingCard drawCard() {
    if (_cards.isEmpty) throw Exception('Deck is empty');
    return _cards.removeLast();
  }

  int remaining() => _cards.length;
}

class PlayerState {
  List<PlayingCard> hand = [];
  int selectionCount = 0; // seçim ekranında seçilenler (kullanılmadı ama bırakıldı)
  double multiplier = 1.0; // kupa papaz etkisi için
  String name;
  bool isBot;

  PlayerState({required this.name, this.isBot = false});

  int currentTotal() => hand.fold<int>(0, (p, c) => p + c.value);

  int finalTotal() => (currentTotal() * multiplier).round();
}

class CardGamePage extends StatefulWidget {
  const CardGamePage({super.key});

  @override
  State<CardGamePage> createState() => _CardGamePageState();
}

// TickerProviderStateMixin eklendi — overlay animasyonlar için gerekli
class _CardGamePageState extends State<CardGamePage> with TickerProviderStateMixin {
  late Deck deck;
  late PlayerState user;
  late PlayerState opponent;
  bool selectionPhase = true;
  bool userTurnToSelect = true; // kullanıcı önce seçer
  List<bool> userSelected = List.filled(5, false);
  List<bool> oppSelected = List.filled(5, false);
  String log = '';

  // Yeni: maç/elde sayacı
  int currentHand = 1;
  final int maxHands = 3; // 3 el oynanacak
  int userHandWins = 0;
  int oppHandWins = 0;

  // Hazır mekanizması
  bool userReady = false;
  bool botReady = false;

  // Yeni: El sonu/başlangıcı overlay kontrolü
  bool showHandResultOverlay = false;
  String handResultText = '';
  bool showReadyOverlay = false;

  // Yeni: Özel kart işaretleme için
  int? swappedUserIndex;
  int? swappedOppIndex;

  // YENİ: Altın sarısı info mesajı için
  String _currentInfoMessage = '';

  // Card keys for animation overlay
  late List<GlobalKey> userCardKeys;
  late List<GlobalKey> oppCardKeys;

  // Log scroll controller
  final ScrollController _logController = ScrollController();

  @override
  void initState() {
    super.initState();
    // initialize keys
    userCardKeys = List.generate(5, (_) => GlobalKey());
    oppCardKeys = List.generate(5, (_) => GlobalKey());
    _startNewMatch();
  }

  // --- MATCH START: Deck oluşturulur sadece burada (maç boyunca aynı desteden çekilir)
  void _startNewMatch() {
    currentHand = 1;
    userHandWins = 0;
    oppHandWins = 0;
    log = '';
    showHandResultOverlay = false;
    showReadyOverlay = false;
    _clearInfoMessage(); // YENİ: Bilgi mesajını temizle
    // Yeni: Swapped kartları sıfırla
    swappedUserIndex = null;
    swappedOppIndex = null;

    // FIX 1: Yeni maç başladığında kartların kapalı (hidden) ve seçim fazının aktif olması için
    selectionPhase = true;
    userTurnToSelect = true;

    _appendLog('=== Yeni Maç Başladı ===');

    deck = Deck(); // sadece maç başında oluşturuldu (önemli revize)
    // Oyuncuları bir kere oluştur (eller maç boyunca aynı elden çekilecek)
    user = PlayerState(name: 'Siz', isBot: false);
    opponent = PlayerState(name: 'Bot', isBot: true);

    // İlk el için kartları dağıt
    _dealInitial();

    // Hazırlık (ready) sürecini başlat
    _prepareHandStart();
  }

  // Yeni el hazırlığı (her elde çağrılır). ÖNEMLİ: oyuncu/opp nesnelerini yeniden oluşturma! (eller saklanır)
  void _startNewHand() {
    // sıfırlamalar: multiplier el başında sıfırlanır, seçilenler sıfırlanır
    user.multiplier = 1.0;
    opponent.multiplier = 1.0;
    userSelected = List.filled(5, false);
    oppSelected = List.filled(5, false);
    showHandResultOverlay = false;
    _clearInfoMessage(); // YENİ: Bilgi mesajını temizle

    // Yeni: Swapped kartları sıfırla
    swappedUserIndex = null;
    swappedOppIndex = null;

    // FIX 2: Yeni el başlarken seçim fazı aktif olmalı (rakip kartları kapalı).
    selectionPhase = true;
    userTurnToSelect = true;
    _appendLog('--- El $currentHand başlıyor (Toplam $maxHands el) ---');

    _prepareHandStart();
  }

  // Her el başında hazır-durumu kur
  void _prepareHandStart() {
    userReady = false;
    botReady = false;
    showReadyOverlay = true; // El başlangıcı overlay'ini göster
    setState(() {});
    // Bot otomatik hazır olur (rastgele 700-1400 ms)
    Future.delayed(Duration(milliseconds: 700 + Random().nextInt(700)), () {
      if (mounted) {
        botReady = true;
        _appendLog('Bot hazır oldu.');
        setState(() {});
        _checkStartHand();
      }
    });
  }

  // Kullanıcı "Hazırım" dediğinde çağrılır
  void _userReadyStartHand() {
    setState(() {
      userReady = true;
      showReadyOverlay = false; // Hazırım overlay'ini kapat
      _appendLog('Siz hazır oldunuz.');
    });
    _checkStartHand();
  }

  // Her iki taraf da hazırsa el başlar (seçim fazı açılır)
  void _checkStartHand() {
    if (userReady && botReady) {
      _appendLog('Her iki taraf da hazır. Seçim fazı başlıyor.');
      // Küçük bir görsel gecikme ver
      Future.delayed(const Duration(milliseconds: 2000), () {
        if (mounted) {
          // selectionPhase = true; // FIX 3: Zaten _startNewHand içinde true olarak ayarlandı.
          userTurnToSelect = true;
          setState(() {});
        }
      });
    }
  }

  void _dealInitial() {
    // Eğer eller zaten doluysa, tekrardan dağıtma (maç başındaki ilk deal için çalışır)
    if (user.hand.isNotEmpty || opponent.hand.isNotEmpty) return;
    user.hand.clear();
    opponent.hand.clear();
    for (int i = 0; i < 5; i++) {
      user.hand.add(deck.drawCard());
      opponent.hand.add(deck.drawCard());
    }
    setState(() {});
  }

  void _toggleSelectUser(int idx) {
    if (!selectionPhase || !userTurnToSelect) return;
    int currentlySelected = userSelected.where((e) => e).length;
    if (!userSelected[idx] && currentlySelected >= 3) return; // en fazla 3
    setState(() {
      userSelected[idx] = !userSelected[idx];
    });
  }

  void _applyUserReplacement() {
    // seçili olanları deck'ten rastgele kartlarla değiştir
    List<int> indices = [];
    for (int i = 0; i < userSelected.length; i++) {
      if (userSelected[i]) indices.add(i);
    }

    // REVİZYON: Hiç kart seçilmese bile akışın devam etmesi sağlandı.
    if (indices.isEmpty) {
      _appendLog('Hiç kart seçilmedi. Değişim atlanıyor.');
    } else {
      // limit: eğer destede kart kalmamışsa hata vermez, sadece kalan kadar değiştirir
      for (var i in indices) {
        if (deck.remaining() == 0) {
          _appendLog('Destede kart kalmadığı için daha fazla değişim yapılamıyor.');
          break;
        }
        user.hand[i] = deck.drawCard();
      }
    }

    userSelected = List.filled(5, false);
    userTurnToSelect = false; // şimdi bot seçer
    setState(() {});
    // Bot seçimini hemen çalıştır (daha yavaş)
    Future.delayed(const Duration(milliseconds: 1200), () => _botReplace());
  }

  void _botReplace() async {
    // Bot rastgele 0-3 kart seçer ve değiştirir
    final rnd = Random();
    int toReplace = rnd.nextInt(4); // 0..3
    Set<int> chosen = {};
    while (chosen.length < toReplace) chosen.add(rnd.nextInt(5));
    for (var idx in chosen) {
      if (deck.remaining() == 0) break;
      opponent.hand[idx] = deck.drawCard();
      oppSelected[idx] = true;
    }
    // kısa süre sonra oppSelected'i temizle (sadece gösterim amaçlı değil)
    await Future.delayed(const Duration(milliseconds: 1200), () {
      if (mounted) {
        oppSelected = List.filled(5, false);
        selectionPhase = false; // seçimler bitti (kartlar açılır)
        setState(() {});
      }
    });
    setState(() {});

    // YENİ: Seçimler bittikten sonra otomatik olarak elleri aç ve özel kartları uygula
    if (!selectionPhase) {
      _revealAndResolve();
    }
  }

  // Reveal ve özel kart işleme
  void _revealAndResolve() async {
    if (selectionPhase) {
      // Bu kontrol artık _botReplace çağrısı sonrasında yapıldığı için teorik olarak buraya düşmemeli.
      _appendLog('Hata: Seçim fazı hala aktifken eller açılamaz.');
      return;
    }

    // İlk olarak eller açılmadan önce kim başlayacak onu belirleyelim: "eller ilk açıldığında"ki toplam
    int userInitial = user.currentTotal();
    int oppInitial = opponent.currentTotal();
    bool userStarts = userInitial >= oppInitial; // eşitlikte kullanıcı başlar

    _appendLog(
        'Eller açıldı. Başlangıç toplamları: Siz=$userInitial, Bot=$oppInitial. ${userStarts ? 'Siz' : 'Bot'} başlıyor.');

    // YENİ: Bilgi mesajı
    _setInfoMessage('Eller Açıldı! Özel Kartlar Uygulanıyor...');
    await Future.delayed(const Duration(milliseconds: 2000));

    // Özel kartların uygulanması sırası
    if (userStarts) {
      await _applySpecialsForPlayer(user, opponent);
      await _applySpecialsForPlayer(opponent, user);
    } else {
      await _applySpecialsForPlayer(opponent, user);
      await _applySpecialsForPlayer(user, opponent);
    }

    // Son toplamı hesapla
    int userFinal = user.finalTotal();
    int oppFinal = opponent.finalTotal();

    // YENİ: Bilgi mesajı
    _setInfoMessage('Puanlama Tamamlandı. Sonuçlar Hesaplanıyor...');
    await Future.delayed(const Duration(milliseconds: 2000));
    _clearInfoMessage(); // Mesajı temizle

    _appendLog('Son durum: Siz=${userFinal}, Bot=${oppFinal}.');

    String result;
    if (userFinal > oppFinal) {
      result = 'Kazanan bu el: Siz!';
      userHandWins++;
    } else if (oppFinal > userFinal) {
      result = 'Kazanan bu el: Bot!';
      oppHandWins++;
    } else {
      result = 'Bu el berabere!';
    }

    _appendLog(result);

    if (mounted) {
      setState(() {});
    }

    // Maçın 3 el olarak oynanması: eğer en son else toplam kazananı göster
    if (currentHand >= maxHands) {
      await Future.delayed(const Duration(milliseconds: 2000));
      if (mounted) {
        _showMatchResultDialog();
      }
    } else {
      // Sonraki ele geçiş: round++ ve yeni el başlat
      currentHand++;
      await Future.delayed(const Duration(milliseconds: 2000));
      if (mounted) {
        // Yeni overlay'i göster: "Kazanan: TARAF" ve 'DEVAM' butonu
        _showHandResultOverlay(result);
      }
    }
  }

  // El sonu sonucunu gösteren overlay'i aktif eder
  void _showHandResultOverlay(String result) {
    setState(() {
      handResultText = result;
      showHandResultOverlay = true;
    });
  }

  // Devam butonuna basıldığında çağrılır: Sonuç ekranını kapatır, yeni el hazırlığını başlatır
  void _continueToNextHand() {
    setState(() {
      showHandResultOverlay = false;
    });
    _startNewHand(); // Yeni el başlat (bu da _prepareHandStart'ı çağırır ve showReadyOverlay'i açar)
  }

  // YENİ: Info mesajı göster/gizle
  void _setInfoMessage(String message) {
    if (!mounted) return;
    setState(() {
      _currentInfoMessage = message;
    });
  }

  void _clearInfoMessage() {
    if (!mounted) return;
    setState(() {
      _currentInfoMessage = '';
    });
  }

  // ----- ÖZEL KART UYGULAMALARI -----
  Future<void> _applySpecialsForPlayer(PlayerState actor, PlayerState target) async {
    // actor sahip olduğu özel kartları tespit et ve sırayla uygula
    // Uygulama sırası: Kupa Papaz (King hearts) -> Sinek 2 (Clubs 2) -> Karo 2 (Diamonds 2)
    List<int> kingIndices = [];
    List<int> clubs2Indices = [];
    List<int> diamonds2Indices = [];

    for (int i = 0; i < actor.hand.length; i++) {
      var c = actor.hand[i];
      if (c.isKingOfHearts) kingIndices.add(i);
      if (c.isClubs2) clubs2Indices.add(i);
      if (c.isDiamonds2) diamonds2Indices.add(i);
    }

    // King of Hearts: oyuncunun elindeki kartların toplamını 2 ile çarpar
    for (var idx in kingIndices) {
      // YENİ: Info Mesajı
      _setInfoMessage('${actor.name} Kupa Papaz (K♥) Etkisini Uyguluyor...');
      await Future.delayed(const Duration(milliseconds: 1600));

      actor.multiplier *= 2;
      _appendLog('${actor.name} Kupa Papaz (K♥) kullandı. Toplamı 2 ile çarpıldı.');
      await Future.delayed(const Duration(milliseconds: 1600));
      setState(() {}); // x2 işaretini hemen göster
    }

    // Clubs 2: oyuncu kendi elinden seçtiği bir kart ile karşı oyuncunun elinden seçtiği bir kartı değiştirir
    for (var idx in clubs2Indices) {
      // YENİ: Info Mesajı
      _setInfoMessage('${actor.name} Sinek İkisi (♣2) ile Kart Takası Başlatıyor...');
      await Future.delayed(const Duration(milliseconds: 700));

      if (actor.isBot) {
        // bot rastgele seçer
        var rnd = Random();
        int myIdx = rnd.nextInt(actor.hand.length);
        int oppIdx = rnd.nextInt(target.hand.length);

        // Swapped kartları kaydet
        if (actor == opponent) {
          // Bot (Opponent) kendi kartını (myIdx) kullanıcı kartı (oppIdx) ile değiştirdi
          swappedOppIndex = myIdx;
          swappedUserIndex = oppIdx;
        } else {
          // Kullanıcı (User) kendi kartını (myIdx) bot kartı (oppIdx) ile değiştirdi
          swappedUserIndex = myIdx;
          swappedOppIndex = oppIdx;
        }

        // Swap gerçekleşti, hemen görseli güncelle (takas işaretleri görünür olur)
        setState(() {});

        // Bot'un yaptığı değişimi animasyonlu göster (rakibin kartının bot eline doğru hareketi)
        await _animateCardTake(
            fromKey: oppCardKeyForIndex(oppIdx), // rakibin kartından alınıyor
            toKey: userCardKeyForIndex(myIdx), // bot kendi kartına koyuyormuş gibi göster (gösterim amaçlı)
            card: target.hand[oppIdx]);

        var myCard = actor.hand[myIdx];
        var oppCard = target.hand[oppIdx];
        actor.hand[myIdx] = oppCard;
        target.hand[oppIdx] = myCard;
        _appendLog('Bot Sinek 2 (♣2) kullandı: Bot elindeki ${myCard} ile sizin ${oppCard} ile yer değiştirdi.');
      } else {
        // kullanıcıdan seçim iste
        _appendLog('Sinek 2 (♣2) kullanıldı. Lütfen elinizden bir kart ve rakibin elinden bir kart seçin.');
        var pair = await _askUserToPickTwoCards(actor.hand, target.hand, 'Sinek 2: Kendi ve rakibin kartını seçin');
        if (pair != null) {
          int myIdx = pair[0];
          int oppIdx = pair[1];

          // Swapped kartları kaydet
          swappedUserIndex = myIdx;
          swappedOppIndex = oppIdx;

          // Swap gerçekleşti, hemen görseli güncelle (takas işaretleri görünür olur)
          setState(() {});

          // Animasyon: rakibin kartı kullanıcının yerine doğru hareket etsin (görsel)
          await _animateCardTake(
              fromKey: oppCardKeyForIndex(oppIdx), toKey: userCardKeyForIndex(myIdx), card: target.hand[oppIdx]);

          var myCard = actor.hand[myIdx];
          var oppCard = target.hand[oppIdx];
          actor.hand[myIdx] = oppCard;
          target.hand[oppIdx] = myCard;
          _appendLog('Sinek 2 uygulandı: Siz ${myCard} ile Botun ${oppCard} ile yer değiştirdiniz.');
        } else {
          _appendLog('Sinek 2 atlandı (seçim yapılmadı).');
        }
      }
      await Future.delayed(const Duration(milliseconds: 2000));
    }

    // Diamonds 2: oyuncu rakip oyuncunun elinden seçtiği bir kartı etkisiz hale getirir.
    for (var idx in diamonds2Indices) {
      // YENİ: Info Mesajı
      _setInfoMessage('${actor.name} Karo İkisi (♦2) ile Kart Etkisizleştiriyor...');
      await Future.delayed(const Duration(milliseconds: 2000));

      if (actor.isBot) {
        var rnd = Random();
        int oppIdx = rnd.nextInt(target.hand.length);
        target.hand[oppIdx].disabled = true;
        _appendLog('Bot Karo 2 (♦2) kullandı: Sizin ${target.hand[oppIdx]} etkisiz hale getirildi.');
      } else {
        _appendLog('Karo 2 (♦2) kullanıldı. Lütfen rakibin elinden etkisizleştirmek istediğiniz kartı seçin.');
        int? oppIdx = await _askUserToPickOneCard(target.hand, 'Karo 2: Rakibin etkisiz olacak kartını seçin');
        if (oppIdx != null) {
          target.hand[oppIdx].disabled = true;
          _appendLog('Karo 2 uygulandı: Botun ${target.hand[oppIdx]} etkisiz hale getirildi.');
        } else {
          _appendLog('Karo 2 atlandı (seçim yapılmadı).');
        }
      }
      await Future.delayed(const Duration(milliseconds: 1200));
    }

    // Uygulama bitince bilgi mesajını temizle
    _clearInfoMessage();

    if (mounted) {
      setState(() {});
    }
  }

  // --- Kart alma animasyonu (overlay ile) ---
  // fromKey/toKey: GlobalKey'ler ile widget pozisyonları alınır, card gösterimi overlay'de hareket eder.
  // REVİZYON 2: Daha dramatik animasyon
  Future<void> _animateCardTake(
      {required GlobalKey? fromKey, required GlobalKey? toKey, required PlayingCard card}) async {
    // Eğer key'ler yoksa model değişimini yapıp geri dön
    if (fromKey == null || toKey == null) return;

    final fromContext = fromKey.currentContext;
    final toContext = toKey.currentContext;
    if (fromContext == null || toContext == null) return;

    final fromBox = fromContext.findRenderObject() as RenderBox?;
    final toBox = toContext.findRenderObject() as RenderBox?;
    if (fromBox == null || toBox == null) return;

    final fromPos = fromBox.localToGlobal(Offset.zero);
    final toPos = toBox.localToGlobal(Offset.zero);

    final overlay = Overlay.of(context);
    if (overlay == null) return;

    // Revizyon: Daha uzun süre ve dramatik eğri
    final controller = AnimationController(duration: const Duration(milliseconds: 1200), vsync: this); // 900 -> 1200 ms
    final animation =
        CurvedAnimation(parent: controller, curve: Curves.fastOutSlowIn); // Curves.easeInOut -> Curves.fastOutSlowIn

    OverlayEntry? entry;
    entry = OverlayEntry(builder: (ctx) {
      return AnimatedBuilder(
        animation: animation,
        builder: (_, __) {
          final dx = lerpDouble(fromPos.dx, toPos.dx, animation.value)!;
          final dy = lerpDouble(fromPos.dy, toPos.dy, animation.value)!;
          final rotation = lerpDouble(0, 2 * pi, animation.value)!; // Ekstra: Kartı 360 derece döndür

          return Positioned(
            left: dx,
            top: dy,
            child: Transform.rotate(
              // Dönüşü ekle
              angle: rotation,
              child: Material(
                color: Colors.transparent,
                child: Opacity(
                  opacity: 1.0 - (animation.value * 0.05),
                  child: _overlayCardWidget(card),
                ),
              ),
            ),
          );
        },
      );
    });

    overlay.insert(entry);
    try {
      await controller.forward();
    } finally {
      entry.remove();
      controller.dispose();
    }
  }

  // Overlay'de gösterilecek basit kart widget (Boyutları daha büyük ve belirgin)
  Widget _overlayCardWidget(PlayingCard c) {
    final isRed = c.suit == Suit.hearts || c.suit == Suit.diamonds;
    return Container(
      width: 70, // Daha belirgin
      height: 100, // Daha belirgin
      decoration: BoxDecoration(
        color: c.disabled ? Colors.grey[400] : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: isRed ? Colors.red.shade800 : Colors.black, width: 2),
        boxShadow: const [BoxShadow(blurRadius: 10, color: Colors.black54, offset: Offset(4, 6))],
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(c.rank,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: isRed ? Colors.red : Colors.black)),
            const SizedBox(height: 8),
            Text(c.suitSymbol, style: TextStyle(fontSize: 24, color: isRed ? Colors.red : Colors.black)),
            const SizedBox(height: 8),
            Text('${c.disabled ? 0 : c.value}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  // Yardımcı: given index, uygun GlobalKey döndürür
  GlobalKey? userCardKeyForIndex(int idx) {
    if (idx < 0 || idx >= userCardKeys.length) return null;
    return userCardKeys[idx];
  }

  GlobalKey? oppCardKeyForIndex(int idx) {
    if (idx < 0 || idx >= oppCardKeys.length) return null;
    return oppCardKeys[idx];
  }

  // REVİZYON 1: Geliştirilmiş Kart Seçim Dialogları
  Widget _buildCardSelectionDialog({
    required String title,
    required String subtitle,
    required List<PlayingCard> hand,
    required Function(int) onCardTap,
    required VoidCallback onCancel,
    required Color borderColor,
  }) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: kTableNavy, // Koyu Tema
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: borderColor, width: 3), // Accent çerçeve
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.8), blurRadius: 25, offset: const Offset(0, 8)),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 22.sp, fontWeight: FontWeight.w900, color: Colors.white)),
            const SizedBox(height: 8),
            Text(subtitle, textAlign: TextAlign.center, style: TextStyle(fontSize: 16.sp, color: Colors.white70)),
            const Divider(color: Colors.white12, height: 24),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: List.generate(hand.length, (i) {
                final card = hand[i];
                final isRed = (card.suit == Suit.hearts || card.suit == Suit.diamonds);
                return GestureDetector(
                  onTap: () => onCardTap(i),
                  child: Container(
                    width: 70,
                    height: 100,
                    decoration: BoxDecoration(
                      color: card.disabled ? Colors.grey.shade600 : Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: borderColor, width: 3), // Accent border
                      boxShadow: [
                        BoxShadow(color: borderColor.withOpacity(0.5), blurRadius: 8),
                      ],
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(card.rank,
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: isRed ? Colors.red.shade800 : Colors.black)),
                          Text(card.suitSymbol,
                              style: TextStyle(fontSize: 24, color: isRed ? Colors.red.shade800 : Colors.black)),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: onCancel,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade600,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: Text('VAZGEÇ / ATLA',
                  style: TextStyle(fontSize: 16.sp, color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Future<List<int>?> _askUserToPickTwoCards(List<PlayingCard> myHand, List<PlayingCard> oppHand, String title) async {
    int? myPick;
    int? oppPick;

    // Kendi kartını seç
    myPick = await showDialog<int>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return _buildCardSelectionDialog(
          title: title,
          subtitle: 'Adım 1/2: Kendi elinizden bir kart seçin (Sinek 2: Takas)',
          hand: myHand,
          onCardTap: (i) => Navigator.pop(ctx, i),
          onCancel: () => Navigator.pop(ctx, null),
          borderColor: Colors.lightBlueAccent, // Kendi kartı için mavi accent
        );
      },
    );
    if (myPick == null) return null;

    // Rakibin kartını seç
    oppPick = await showDialog<int>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return _buildCardSelectionDialog(
          title: title,
          subtitle: 'Adım 2/2: Rakibin elinden bir kart seçin (Sinek 2: Takas)',
          hand: oppHand,
          onCardTap: (i) => Navigator.pop(ctx, i),
          onCancel: () => Navigator.pop(ctx, null),
          borderColor: Colors.redAccent, // Rakip kartı için kırmızı accent
        );
      },
    );
    if (oppPick == null) return null;

    return [myPick, oppPick];
  }

  Future<int?> _askUserToPickOneCard(List<PlayingCard> hand, String title) async {
    int? pick = await showDialog<int>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return _buildCardSelectionDialog(
          title: title,
          subtitle: 'Etkisizleştirmek için rakip kartını seçin (Karo 2: Etkisizleştirme)',
          hand: hand,
          onCardTap: (i) => Navigator.pop(ctx, i),
          onCancel: () => Navigator.pop(ctx, null),
          borderColor: Colors.orangeAccent, // Etkisizleştirme için turuncu accent
        );
      },
    );
    return pick;
  }

  void _appendLog(String s) {
    if (!mounted) return;
    setState(() {
      final time = DateTime.now().toIso8601String().split('T').last.substring(0, 8);
      log = '$time - $s\n' + log;
    });
  }

  // Kart widget (orijinal yapıyı koruyarak)
  // REVİZYON 3: Geliştirilmiş Kart Görsel Efektleri
  Widget _buildCardWidget(PlayingCard c, bool selected,
      {required VoidCallback onTap, required bool isSpecial, required bool wasSwapped}) {
    // Sınır rengini ve kalınlığını ayarla
    Color baseBorderColor = isSpecial && !c.disabled ? Colors.amberAccent : Colors.black26;
    double baseBorderWidth = isSpecial && !c.disabled ? 3 : 1;

    // Swapped için pulsasyon animasyonu
    return TweenAnimationBuilder<Color?>(
      tween: ColorTween(
        // Takas edilmiş kartlar için mor ve beyaz arasında titreşim
        begin: wasSwapped ? Colors.purpleAccent : baseBorderColor,
        end: wasSwapped ? Colors.white : baseBorderColor,
      ),
      duration: wasSwapped ? const Duration(milliseconds: 700) : Duration.zero,
      curve: Curves.easeInOut,
      // Tekrarlı animasyon için dışarıda bir Controller ve AnimatedBuilder daha iyi olurdu,
      // ancak burada basit bir "titreşim" etkisi için TweenAnimationBuilder'ı kullanıyoruz.
      builder: (context, color, child) {
        Color finalBorderColor = selected ? Colors.blue : color ?? baseBorderColor;
        double finalBorderWidth = selected
            ? 3
            : wasSwapped
                ? 4 // Daha kalın ve mor/beyaz arasında titreşen sınır
                : baseBorderWidth;

        return GestureDetector(
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeInOut,
            margin: EdgeInsets.only(top: selected ? 0 : 8),
            transform: Matrix4.translationValues(0, selected ? -14 : 0, 0),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: finalBorderColor, width: finalBorderWidth),
              boxShadow: [
                const BoxShadow(blurRadius: 4, color: Colors.black12, offset: Offset(1, 2)),
                // Kupa Papaz (K♥) için Altın Parlaklık efekti (Sadece özel kart ve etkisiz değilse)
                if (c.isKingOfHearts && !c.disabled)
                  BoxShadow(
                    color: Colors.amber.withOpacity(0.8),
                    blurRadius: 10,
                    spreadRadius: 1,
                    offset: Offset(0, 0),
                  ),
              ],
            ),
            width: 60,
            height: 92,
            child: Stack(
              children: [
                // Kart içeriği
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(c.rank, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Text(c.suitSymbol,
                          style: TextStyle(
                              fontSize: 18,
                              color: (c.suit == Suit.hearts || c.suit == Suit.diamonds) ? Colors.red : Colors.black)),
                      const SizedBox(height: 6),
                      // Etkisiz kart değeri "0" olarak daha belirgin
                      Text('${c.disabled ? '0' : c.value}',
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              color: c.disabled ? Colors.red.shade800 : Colors.black)),
                    ],
                  ),
                ),
                // Etkisiz (Disabled) Overlay - Karo 2 (♦2) etkisi
                if (c.disabled)
                  // Mevcut sallanma animasyonunu koru ve üzerine X işareti ekle
                  TweenAnimationBuilder<double>(
                    tween: Tween(begin: -0.05, end: 0.05),
                    duration: const Duration(milliseconds: 400),
                    curve: Curves.easeInOut,
                    onEnd: () {
                      // Animasyonu sürekli ters yöne doğru tetiklemek için setState (basit bir loop)
                      if (mounted) setState(() {});
                    },
                    builder: (context, angle, child) {
                      return Transform.rotate(
                        angle: angle,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.6), // Daha opak hale getir
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.redAccent, width: 3),
                          ),
                          child: Center(
                              child: Icon(Icons.close_rounded, size: 40, color: Colors.red.shade800)), // Kırmızı X
                        ),
                      );
                    },
                  ),
                // Sinek 2 (♣2) - Takas Edilmiş İşareti
                if (wasSwapped && !c.disabled)
                  Positioned(
                    top: 4,
                    right: 4,
                    child: Container(
                      padding: const EdgeInsets.all(2),
                      decoration: const BoxDecoration(
                        color: Colors.purple,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.swap_horiz, size: 16, color: Colors.white),
                    ),
                  ),
                // Kupa Papaz (K♥) - Çarpan İşareti
                if (c.isKingOfHearts && !c.disabled)
                  const Positioned(
                    bottom: 4,
                    left: 4,
                    child: Text('x2',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Colors.redAccent,
                            shadows: [Shadow(blurRadius: 4, color: Colors.red, offset: Offset(1, 1))])),
                  )
              ],
            ),
          ),
        );
      },
    );
  }

  // Yeni: El sonu sonuç overlay'i
  Widget _buildHandResultOverlay() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return ScaleTransition(scale: animation, child: child);
      },
      child: showHandResultOverlay
          ? Container(
              color: Colors.black.withOpacity(0.5),
              alignment: Alignment.center,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.green.shade800,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.white, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.8),
                      blurRadius: 15,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      handResultText,
                      style: TextStyle(
                        fontSize: 24.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.yellowAccent,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _continueToNextHand,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      child: Text(
                        'DEVAM',
                        style: TextStyle(fontSize: 18.sp, color: Colors.green.shade900, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            )
          : const SizedBox.shrink(),
    );
  }

  // Yeni: El başlangıcı hazır olma overlay'i
  Widget _buildReadyOverlay() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return FadeTransition(opacity: animation, child: ScaleTransition(scale: animation, child: child));
      },
      child: showReadyOverlay
          ? Container(
              color: Colors.black.withOpacity(0.6),
              alignment: Alignment.center,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.blueGrey.shade700,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.lightBlueAccent, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.8),
                      blurRadius: 15,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${currentHand}. El Başlıyor...',
                      style: TextStyle(
                        fontSize: 24.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      botReady ? 'Bot hazır. Bekleniyor...' : 'Bot bekleniyor...',
                      style: TextStyle(
                        fontSize: 16.sp,
                        color: botReady ? Colors.greenAccent : Colors.amberAccent,
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: userReady ? null : _userReadyStartHand,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: userReady ? Colors.grey : Colors.lightBlueAccent,
                        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      child: Text(
                        userReady ? 'HAZIR' : 'HAZIRIM',
                        style: TextStyle(
                            fontSize: 18.sp,
                            color: userReady ? Colors.white70 : Colors.black,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            )
          : const SizedBox.shrink(),
    );
  }

  // YENİ: Info Mesajı Overlay'i
  Widget _buildInfoMessageOverlay() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return FadeTransition(opacity: animation, child: ScaleTransition(scale: animation, child: child));
      },
      child: _currentInfoMessage.isNotEmpty
          ? Positioned(
              top: MediaQuery.of(context).size.height * 0.4, // Ekranın ortasına yakın
              left: 0,
              right: 0,
              key: ValueKey(_currentInfoMessage), // Mesaj değiştiğinde animasyon tetiklenir
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.8),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.amberAccent, width: 2), // Altın Sarısı çerçeve
                    boxShadow: [
                      BoxShadow(
                        color: Colors.amber.withOpacity(0.5),
                        blurRadius: 10,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Text(
                    _currentInfoMessage,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.amberAccent, // Altın Sarısı Metin
                    ),
                  ),
                ),
              ),
            )
          : const SizedBox.shrink(key: ValueKey('empty')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kTableGreen,
      drawer: Drawer(
        elevation: 16,
        child: SafeArea(
          child: Column(
            children: [
              const ListTile(title: Text('Oyun Logları')),
              const Divider(),
              Expanded(
                child: SingleChildScrollView(
                  reverse: true,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(log, style: const TextStyle(fontFamily: 'monospace')),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          // Arkaplan ve Oyun Alanı
          Container(
            width: 1.sw,
            height: 1.sh,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/asset/bg.jpg'),
                fit: BoxFit.cover,
                opacity: 0.9,
              ),
            ),
            child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/asset/table.png'),
                  fit: BoxFit.contain,
                ),
              ),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(height: 10.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        ImageButton(onTap: _startNewMatch, imagePath: 'assets/asset/refresh.png'),
                        SizedBox(width: 10.w),
                      ],
                    ),
                    SizedBox(height: 6.h),

                    // Hazır durumu göstergesi (eski, artık sadece bilgi amaçlı)
                    Container(
                      width: 0.9.sw,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('El $currentHand / $maxHands', style: TextStyle(color: Colors.white, fontSize: 14.sp)),
                          Row(
                            children: [
                              Chip(
                                backgroundColor: botReady ? Colors.green[400] : Colors.grey[600],
                                label: Text('Bot: ${botReady ? "Hazır" : "Bekliyor"}'),
                              ),
                              const SizedBox(width: 8),
                              // Buradaki 'Hazırım' butonu artık _buildReadyOverlay'e taşındı.
                              // Sadece seçim aşamasında değilken ve hazır değilken görünüyor.
                              if (!selectionPhase && !userReady)
                                ElevatedButton(
                                  onPressed: null, // Pasif bırak
                                  child: Text(userReady ? 'Hazır' : 'Bekleniyor...'),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 18.h),
                    InfoProfile(
                        p: opponent,
                        currentHand: currentHand,
                        maxHands: maxHands,
                        userWins: userHandWins,
                        oppWins: oppHandWins),
                    const Spacer(),
                    _buildHandRow(opponent, isTop: true),
                    Container(
                      width: 100.w,
                      height: 150.h,
                      decoration: BoxDecoration(
                        image: DecorationImage(image: Image.asset('assets/asset/deck.png').image, fit: BoxFit.cover),
                      ),
                      child: Center(
                          child: Container(
                        margin: const EdgeInsets.all(1),
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.8),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: kTableNavy, width: 2),
                        ),
                        child: Text('${deck.remaining()} kart',
                            style: TextStyle(color: kTableNavy, fontSize: 20.sp, fontWeight: FontWeight.bold)),
                      )),
                    ),
                    if (selectionPhase && userTurnToSelect)
                      Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(height: 15.h),
                            Text('Kart değişimi: En fazla 3 kart seçebilirsiniz.',
                                style: TextStyle(color: kWhiteColor, fontSize: 16.sp)),
                            const SizedBox(height: 6),
                            // REVİZE EDİLMİŞ BUTON TASARIMI
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  // Butona hafif bir parlaklık ve derinlik katmak için gölge
                                  BoxShadow(
                                    color: Colors.amberAccent.withOpacity(0.4),
                                    blurRadius: 10,
                                    spreadRadius: 1,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: ElevatedButton(
                                onPressed: () {
                                  _applyUserReplacement();
                                },
                                style: ElevatedButton.styleFrom(
                                  // Arkaplan: Koyu Masa Teması
                                  backgroundColor: kTableNavy,
                                  // Kenarlık: Altın Sarısı Accent
                                  side: const BorderSide(color: Colors.amberAccent, width: 3),
                                  // Köşe yuvarlaklığı
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                                  elevation: 0, // Kendi gölgemizi kullandığımız için default elevation'ı sıfırla
                                ),
                                child: Text(
                                  'SEÇİLİ KARTLARI DEĞİŞTİR / ATLA',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 17.sp,
                                    fontWeight: FontWeight.bold,
                                    shadows: [
                                      // Yazıya hafif parlaklık
                                      Shadow(
                                        blurRadius: 4.0,
                                        color: Colors.yellow.withOpacity(0.7),
                                        offset: const Offset(0.5, 0.5),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ]),
                    SizedBox(height: 12.h),
                    _buildHandRow(user, isTop: false),
                    Expanded(
                      child: Container(
                        width: 0.8.sw,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.black.withOpacity(0.95),
                              Colors.grey.shade900,
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white24, width: 1),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.5),
                              blurRadius: 8,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: SingleChildScrollView(
                          controller: _logController,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: log.split('\n').map((line) {
                              Color textColor = Colors.white;
                              if (line.toLowerCase().contains("kullanıcı") || line.toLowerCase().contains("siz")) {
                                textColor = Colors.cyanAccent;
                              } else if (line.toLowerCase().contains("bot")) {
                                textColor = Colors.pinkAccent;
                              } else if (line.toLowerCase().contains("kazanan")) {
                                textColor = Colors.greenAccent;
                              }

                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: 2),
                                child: Text(
                                  line,
                                  style: TextStyle(
                                    fontFamily: 'monospace',
                                    fontSize: 13,
                                    height: 1.3,
                                    color: textColor,
                                    shadows: [
                                      Shadow(
                                        blurRadius: 6,
                                        color: textColor.withOpacity(0.6),
                                        offset: const Offset(0, 0),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ),
                    // Yorum Satırı: Eller Aç ve Özel Kartları Uygula butonu kaldırıldı ve otomatikleştirildi.
                    // if (!selectionPhase && !showHandResultOverlay && !showReadyOverlay) ...[
                    //   const SizedBox(height: 8),
                    //   ElevatedButton(
                    //       onPressed: _revealAndResolve, child: const Text('Eller Aç ve Özel Kartları Uygula')),
                    //   SizedBox(height: 30.h),
                    // ],
                    SizedBox(height: 30.h), // Butonun kapladığı alanı koru
                    InfoProfile(
                        p: user,
                        currentHand: currentHand,
                        maxHands: maxHands,
                        userWins: userHandWins,
                        oppWins: oppHandWins),
                    const Spacer(),
                  ],
                ),
              ),
            ),
          ),

          // Yeni: El sonu sonuç overlay'i
          _buildHandResultOverlay(),

          // Yeni: El başlangıcı hazır olma overlay'i
          _buildReadyOverlay(),

          // YENİ: Info Mesaj Overlay'i
          _buildInfoMessageOverlay(),
        ],
      ),
    );
  }

  Widget _buildHandRow(PlayerState p, {required bool isTop}) {
    bool showFace = !selectionPhase;
    bool isCurrentTurn =
        (p == user && userTurnToSelect && selectionPhase) || (p == opponent && !userTurnToSelect && selectionPhase);

    return Column(
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 800),
          curve: Curves.easeInOut,
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            border: Border.all(
              color: isCurrentTurn ? Colors.yellowAccent : Colors.transparent,
              width: isCurrentTurn ? 4 : 0,
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: isCurrentTurn
                ? [BoxShadow(color: Colors.yellow.withOpacity(0.7), blurRadius: 20, spreadRadius: 2)]
                : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(p.hand.length, (i) {
              var c = p.hand[i];
              bool selected = p == user ? userSelected[i] : oppSelected[i];

              // Yeni: Özel kart ve takas durumu
              bool isSpecialCard = c.isKingOfHearts || c.isClubs2 || c.isDiamonds2;
              bool wasSwappedCard = (p == user && swappedUserIndex == i) || (p == opponent && swappedOppIndex == i);

              // container'a global key ver (animasyon için)
              final gw = p == user ? userCardKeys[i] : oppCardKeys[i];

              return AnimatedSwitcher(
                duration: const Duration(milliseconds: 400),
                transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
                child: GestureDetector(
                  key: ValueKey('${c.rank}${c.suitSymbol}${c.disabled}${p == user ? "u" : "o"}$i'),
                  onTap: () {
                    if (p == user) _toggleSelectUser(i);
                  },
                  child: Container(
                    key: gw,
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    child: showFace || p == user
                        ? _buildCardWidget(
                            c,
                            selected,
                            onTap: () {
                              if (p == user) _toggleSelectUser(i);
                            },
                            isSpecial: isSpecialCard && showFace, // Sadece el açılınca özel olarak işaretle
                            wasSwapped: wasSwappedCard && showFace, // Sadece el açılınca takas edilmiş olarak işaretle
                          )
                        : Container(
                            width: 55, // Kart genişliği ile uyumlu hale getirildi
                            height: 85, // Kart yüksekliği ile uyumlu hale getirildi
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              image: const DecorationImage(
                                image: AssetImage('assets/asset/lock.png'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                  ),
                ),
              );
            }),
          ),
        ),
      ],
    );
  }

  Future<void> _showMatchResultDialog() async {
    String overall;
    String lottiePath;
    if (userHandWins > oppHandWins) {
      overall = 'Maçın kazananı: Siz!';
      lottiePath = 'assets/lottie/win.json'; // konfeti, kupa animasyonu
    } else if (oppHandWins > userHandWins) {
      overall = 'Maçın kazananı: Bot!';
      lottiePath = 'assets/lottie/lose.json'; // üzgün surat, kırık kalp animasyonu
    } else {
      overall = 'Maç berabere!';
      lottiePath = 'assets/lottie/draw.json'; // el sıkışma vb.
    }

    await showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: "Result",
      transitionDuration: const Duration(milliseconds: 500),
      pageBuilder: (_, __, ___) {
        return Center(
          child: Material(
            color: Colors.transparent,
            child: Container(
              width: MediaQuery.of(context).size.width * 0.8,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "3 El Tamamlandı",
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: 120,
                    height: 120,
                    child: Lottie.asset(lottiePath, repeat: true),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '$overall\n\nSkor — Siz: $userHandWins  Bot: $oppHandWins',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70, fontSize: 16),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton.icon(
                        onPressed: () {
                          Navigator.pop(context);
                          _startNewMatch();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        icon: const Icon(Icons.refresh, color: Colors.white),
                        label: const Text("Yeniden Başlat", style: TextStyle(color: Colors.white)),
                      ),
                      ElevatedButton.icon(
                        onPressed: () => Navigator.pop(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        icon: const Icon(Icons.close, color: Colors.white),
                        label: const Text("Kapat", style: TextStyle(color: Colors.white)),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        );
      },
      transitionBuilder: (_, anim, __, child) {
        return Transform.scale(
          scale: Curves.easeOutBack.transform(anim.value),
          child: Opacity(
            opacity: anim.value,
            child: child,
          ),
        );
      },
    );
  }
}

class InfoProfile extends StatelessWidget {
  InfoProfile({
    super.key,
    required this.p,
    this.currentHand = 1,
    this.maxHands = 3,
    this.userWins = 0,
    this.oppWins = 0,
  });
  PlayerState p;
  int currentHand;
  int maxHands;
  int userWins;
  int oppWins;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 0.9.sw,
        height: 60.h,
        padding: const EdgeInsets.symmetric(horizontal: 6),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.6),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.yellowAccent, width: 2),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 22.sp,
              backgroundColor: Colors.white,
              child: const Icon(Icons.person, color: Colors.grey),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      // YENİ: Toplamı finalTotal() ile büyüt ve renklendir
                      Text('${p.name} — ',
                          style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold, color: Colors.white)),
                      Text('Toplam: ${p.finalTotal()}', // *** DÜZELTİLDİ: finalTotal kullanılıyor
                          style: TextStyle(
                              fontSize: 22.sp, // *** BÜYÜTÜLDÜ
                              fontWeight: FontWeight.w900,
                              color: Colors.amberAccent, // *** SOFT RENK
                              shadows: [
                                Shadow(
                                  blurRadius: 5.0,
                                  color: Colors.amber.withOpacity(0.8),
                                  offset: Offset(1.0, 1.0),
                                ),
                              ])),
                      // Kupa Papaz x2 İşareti
                      if (p.multiplier > 1.0)
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: Text('x${p.multiplier.toInt()}',
                              style: TextStyle(
                                fontSize: 24.sp,
                                fontWeight: FontWeight.w900,
                                color: Colors.redAccent,
                                shadows: [
                                  Shadow(
                                    blurRadius: 5.0,
                                    color: Colors.red.withOpacity(0.8),
                                    offset: Offset(1.0, 1.0),
                                  ),
                                ],
                              )),
                        ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text('El $currentHand / $maxHands  • Skor: Siz $userWins - Bot $oppWins',
                      style: TextStyle(fontSize: 12.sp, color: Colors.white70)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Çapraz çizgili overlay painter - ARTIK KULLANILMIYOR
class _DisabledStripePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.red.withOpacity(0.4)
      ..strokeWidth = 2;

    for (double i = -size.height; i < size.width; i += 8) {
      canvas.drawLine(Offset(i, 0), Offset(i + size.height, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
