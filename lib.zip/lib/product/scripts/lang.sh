#!/bin/bash

dart run easy_localization:generate  -O lib/product/initial/language -f keys -o locale_keys.g.dart --source-dir assets/translations