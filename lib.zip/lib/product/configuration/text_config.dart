class TextConfig {
  static const double textScaleFactor = 1.0;
}
