enum CustomAlertType { success, error, warning, info, custom }
