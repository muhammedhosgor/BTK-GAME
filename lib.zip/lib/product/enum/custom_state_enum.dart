enum CustomStateEnum<T> {
  initial,
  loading,
  completed,
  error,
}
