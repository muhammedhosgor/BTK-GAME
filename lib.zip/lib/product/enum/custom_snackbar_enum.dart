enum SnackBarTypes {
  error,
  success,
  warning,
  info,
}
