// Projeye configuration değerlerinin tutulduğu soyut sınıf

abstract class AppConfiguration {
  //  baseUrl ve apiKey değerlerini soyut sınıf içerisinde tanımladık.
  String get baseUrl;
  String get apiKey;
}
