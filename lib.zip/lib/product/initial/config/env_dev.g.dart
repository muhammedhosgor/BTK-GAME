// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'env_dev.dart';

// **************************************************************************
// EnviedGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
final class _DevEnv {
  static const List<int> _enviedkey_baseUrl = <int>[
    1953047764,
    710695086,
    3795872017,
    4243187580,
    1547555722,
    2679511522,
    584089767,
    3094005049,
    1046124497,
    680479141,
    2330183870,
    3995739004,
    237816218,
    3724399989,
    865060992,
    1543881673,
    3666964817,
    1294040178,
    990504974,
  ];

  static const List<int> _envieddata_baseUrl = <int>[
    1953047740,
    710695130,
    3795872101,
    4243187468,
    1547555833,
    2679511512,
    584089736,
    3094005014,
    1046124464,
    680479175,
    2330183901,
    3995738962,
    237816313,
    3724399898,
    865061101,
    1543881702,
    3666964784,
    1294040066,
    990505063,
  ];

  static final String _baseUrl = String.fromCharCodes(List<int>.generate(
    _envieddata_baseUrl.length,
    (int i) => i,
    growable: false,
  ).map((int i) => _envieddata_baseUrl[i] ^ _enviedkey_baseUrl[i]));

  static const List<int> _enviedkey_apiKey = <int>[
    470292079,
    80218532,
    2623644868,
    412749486,
    2990002884,
    3298009504,
  ];

  static const List<int> _envieddata_apiKey = <int>[
    470291979,
    80218561,
    2623644850,
    412749471,
    2990002934,
    3298009491,
  ];

  static final String _apiKey = String.fromCharCodes(List<int>.generate(
    _envieddata_apiKey.length,
    (int i) => i,
    growable: false,
  ).map((int i) => _envieddata_apiKey[i] ^ _enviedkey_apiKey[i]));
}
