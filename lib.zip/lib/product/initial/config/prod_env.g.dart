// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'prod_env.dart';

// **************************************************************************
// EnviedGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
final class _ProdEnv {
  static const List<int> _enviedkey_baseUrl = <int>[
    3936428359,
    1253834907,
    2979590499,
    4035972799,
    4069150795,
    1567076017,
    613256202,
    365748033,
    2241791834,
    1335509604,
    2248311218,
    1235399249,
    1597779663,
    48834570,
    3040157780,
    3089951162,
    2869333272,
    1041676555,
    819740570,
  ];

  static const List<int> _envieddata_baseUrl = <int>[
    3936428335,
    1253834991,
    2979590423,
    4035972815,
    4069150776,
    1567075979,
    613256229,
    365748078,
    2241791803,
    1335509510,
    2248311249,
    1235399295,
    1597779628,
    48834661,
    3040157753,
    3089951125,
    2869333369,
    1041676667,
    819740659,
  ];

  static final String _baseUrl = String.fromCharCodes(List<int>.generate(
    _envieddata_baseUrl.length,
    (int i) => i,
    growable: false,
  ).map((int i) => _envieddata_baseUrl[i] ^ _enviedkey_baseUrl[i]));

  static const List<int> _enviedkey_apiKey = <int>[
    2858317133,
    658458384,
    1495683158,
    2460133229,
    2427818095,
    2579750048,
  ];

  static const List<int> _envieddata_apiKey = <int>[
    2858317097,
    658458485,
    1495683104,
    2460133212,
    2427818077,
    2579750035,
  ];

  static final String _apiKey = String.fromCharCodes(List<int>.generate(
    _envieddata_apiKey.length,
    (int i) => i,
    growable: false,
  ).map((int i) => _envieddata_apiKey[i] ^ _enviedkey_apiKey[i]));
}
