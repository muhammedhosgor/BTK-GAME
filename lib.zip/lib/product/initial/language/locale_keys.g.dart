// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const home_title = 'home.title';
  static const home_description = 'home.description';
  static const home = 'home';
  static const general_button_save = 'general.button.save';
  static const general_button_cancel = 'general.button.cancel';
  static const general_button = 'general.button';
  static const general = 'general';
  static const dialog_version = 'dialog.version';
  static const dialog = 'dialog';

}
